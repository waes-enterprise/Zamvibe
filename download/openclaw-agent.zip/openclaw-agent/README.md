# OpenClaw Agent

A simple AI agent that runs on GitHub Actions. Trigger it from your phone anytime.

## How It Works

1. You push code to GitHub
2. GitHub Actions runs `main.py` (calls an AI API)
3. The AI's response is saved to `output.txt`
4. You can download the output from GitHub

---

## Setup (One-Time, 5 Minutes)

### Step 1: Create the GitHub Repo

1. Go to [github.com/new](https://github.com/new) on your phone or computer
2. Repository name: `openclaw-agent`
3. Make it **Private** (recommended)
4. Do NOT add a README — leave everything unchecked
5. Click **Create repository**

### Step 2: Upload These Files

You can do this from your phone:

**Method A — GitHub Mobile App (Easiest):**
1. Open the **GitHub app** on your phone
2. Tap your repo `openclaw-agent`
3. Tap the **+** button at the bottom
4. Tap **Create new file**
5. Upload each file one by one:
   - `main.py`
   - `requirements.txt`
   - `.github/workflows/agent.yml` (create the folder by typing `.github/workflows/agent.yml` as the filename)

**Method B — From Computer:**
1. Clone the repo
2. Copy in the files
3. Push

### Step 3: Add Your API Key

1. Open your repo on GitHub (phone or computer)
2. Go to **Settings** (gear icon)
3. Tap **Secrets and variables** > **Actions**
4. Tap **New repository secret**
5. Name: `OPENAI_API_KEY`
6. Value: paste your OpenAI API key (starts with `sk-...`)
7. Tap **Add secret**

> **No OpenAI key?** You can use DeepSeek instead — they give free credits.
> Get one at [platform.deepseek.com](https://platform.deepseek.com).
> Then in `main.py`, uncomment the DeepSeek lines and comment out the OpenAI lines.

---

## How to Trigger From Your Phone

### Manual Trigger (Anytime)

1. Open the **GitHub app** on your phone
2. Tap your repo **openclaw-agent**
3. Tap the **Actions** tab at the top
4. You'll see **"OpenClaw Agent"** in the workflow list — tap it
5. Tap **"Run workflow"** button
6. Tap the green **"Run workflow"** confirm button
7. Wait ~30 seconds, then pull down to refresh
8. You'll see a new run appear — tap it to watch it live
9. When it finishes (green checkmark), scroll down to **Artifacts**
10. Tap **agent-output** to download the result

### Automatic Trigger

The agent also runs **every 1 hour** automatically. No action needed.

---

## File Structure

```
openclaw-agent/
  main.py                        # The AI agent script
  requirements.txt               # Python dependencies
  .github/
    workflows/
      agent.yml                  # GitHub Actions workflow
```

---

## Switching to DeepSeek

Open `main.py` and change these two lines:

```python
# Change FROM:
AI_BASE_URL = "https://api.openai.com/v1"
AI_MODEL = "gpt-4o-mini"

# Change TO:
AI_BASE_URL = "https://api.deepseek.com/v1"
AI_MODEL = "deepseek-chat"
```

Then use your DeepSeek API key as `OPENAI_API_KEY` in GitHub Secrets.

---

## Troubleshooting

**"Run workflow" button is missing?**
Make sure you have at least one commit in the repo with the `.github/workflows/agent.yml` file.

**Workflow fails with API error?**
Check that your `OPENAI_API_KEY` secret is set correctly and has credits.

**Workflow runs but output is empty?**
Check the workflow logs — tap the workflow run, then tap each step to see the error.

**Want to change what the AI does?**
Edit the `PROMPT` variable at the top of `main.py`.
