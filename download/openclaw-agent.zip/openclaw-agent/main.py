"""
OpenClaw Agent — A simple AI agent that runs on GitHub Actions.

This script:
  1. Calls an AI API (OpenAI by default, swap base_url for DeepSeek)
  2. Sends a test prompt
  3. Prints the AI's response
  4. Saves the response to output.txt

API Key is read from the OPENAI_API_KEY environment variable.
GitHub Actions sets this automatically from your repo secrets.
"""

import os
import datetime
from openai import OpenAI

# ============================================================
#  CONFIGURATION
# ============================================================

# --- Choose your AI provider ---
# Option A: OpenAI (default)
AI_BASE_URL = "https://api.openai.com/v1"
AI_MODEL = "gpt-4o-mini"

# Option B: DeepSeek (uncomment the two lines below instead)
# AI_BASE_URL = "https://api.deepseek.com/v1"
# AI_MODEL = "deepseek-chat"

# The prompt we send to the AI
PROMPT = (
    "You are OpenClaw, a helpful AI assistant. "
    "Give a brief, friendly greeting and mention the current date and time. "
    "Keep it to 2-3 sentences max."
)


# ============================================================
#  MAIN LOGIC
# ============================================================

def run_agent():
    """Main function — calls the AI and saves the result."""

    # --- Step 1: Check for API key ---
    api_key = os.environ.get("OPENAI_API_KEY", "")
    if not api_key:
        print("ERROR: OPENAI_API_KEY environment variable is not set.")
        print("Please add it as a GitHub Actions secret.")
        return

    print(f"[{timestamp()}] OpenClaw Agent starting...")
    print(f"  Model : {AI_MODEL}")
    print(f"  API   : {AI_BASE_URL}")
    print()

    # --- Step 2: Initialize the OpenAI client ---
    # This works with OpenAI, DeepSeek, and any OpenAI-compatible API.
    # Just change AI_BASE_URL and AI_MODEL above.
    client = OpenAI(
        api_key=api_key,
        base_url=AI_BASE_URL,
    )

    # --- Step 3: Send the prompt to the AI ---
    print(f"[{timestamp()}] Sending prompt to AI...")

    try:
        response = client.chat.completions.create(
            model=AI_MODEL,
            messages=[
                {
                    "role": "system",
                    "content": "You are OpenClaw, a concise and friendly AI assistant."
                },
                {
                    "role": "user",
                    "content": PROMPT
                }
            ],
            max_tokens=200,
            temperature=0.7,
        )

        # --- Step 4: Extract the AI's reply ---
        ai_reply = response.choices[0].message.content
        print(f"[{timestamp()}] AI responded successfully!")
        print()
        print("=" * 50)
        print(ai_reply)
        print("=" * 50)

        # --- Step 5: Save to output.txt ---
        output = build_output(ai_reply)
        with open("output.txt", "w", encoding="utf-8") as f:
            f.write(output)

        print()
        print(f"[{timestamp()}] Response saved to output.txt")

    except Exception as e:
        print(f"[{timestamp()}] ERROR: {e}")
        # Save error to output.txt so we can debug from GitHub
        with open("output.txt", "w", encoding="utf-8") as f:
            f.write(f"ERROR at {timestamp()}\n\n{str(e)}\n")


def build_output(ai_reply: str) -> str:
    """Build the content that gets saved to output.txt."""
    lines = []
    lines.append("OPENCLAW AGENT — OUTPUT")
    lines.append(f"Generated: {datetime.datetime.utcnow().isoformat()}Z")
    lines.append(f"Model: {AI_MODEL}")
    lines.append("=" * 50)
    lines.append("")
    lines.append(ai_reply)
    lines.append("")
    lines.append("=" * 50)
    lines.append("End of output.")
    return "\n".join(lines)


def timestamp() -> str:
    """Return a simple UTC timestamp string."""
    return datetime.datetime.utcnow().strftime("%H:%M:%S")


# ============================================================
#  RUN
# ============================================================

if __name__ == "__main__":
    run_agent()
